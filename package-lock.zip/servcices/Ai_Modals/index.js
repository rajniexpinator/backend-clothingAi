const KolorsTryOn = require("./KolorsTryOn");

const All_Ai_Modals ={
    KolorsTryOn:KolorsTryOn,
}
module.exports = All_Ai_Modals